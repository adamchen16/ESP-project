This directory contains ports of some sample applications that I found interesting
and I used to exercise the API in C# and F#.   They are usually line-by-line ports
and of exploratory nature, helping me learn what idioms work and which ones do not
work for the binding.

The ImageCompression sample will require you to use a TensorFlow that has been 
configured to support large protocol buffers, otherwise the program will crash.
