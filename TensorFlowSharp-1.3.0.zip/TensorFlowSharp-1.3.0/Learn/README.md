This contains a port of parts of the TensorFlow Learn framework, as found on

tensorflow/contrib/learn/python/learn

