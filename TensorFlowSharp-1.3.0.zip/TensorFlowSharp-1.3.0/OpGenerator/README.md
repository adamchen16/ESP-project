
This directory contains the operations generator, it is a tool that produces
part of the TFGraph convenience API, based on the tensorflow metadata.

This needs to be run if you update your libtensorflow shared library with a
new version and you want to get access to new operations or when you want 
to upgrade the implementation.